export enum EventTypeName {
  Standard = 0,
  Weekly,
  Monthly,
  Yearly,
}
